package org.ka2ddo.yaac;
/*
 * Copyright (C) 2011-2022 Andrew Pavlin, KA2DDO
 * This file is part of the sample plugin for YAAC (Yet Another APRS Client).
 *
 *  YAAC is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  YAAC is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  and GNU Lesser General Public License along with YAAC.  If not,
 *  see <http://www.gnu.org/licenses/>.
 */
import org.ka2ddo.yaac.ax25.StationTracker;
import org.ka2ddo.yaac.pluginapi.Provider;

/**
 * This sample plugin provides a few additional functions and an alternate properties
 * file for testing the plugin API.
 * @author Andrew Pavlin, KA2DDO
 */
public class SamplePluginProvider extends Provider {
    public SamplePluginProvider() {
        super("YAAC Sample Plug-in", "V0.1", "Andrew Pavlin, KA2DDO", "<html>Sample plug-in for YAAC</html>");
    }

    /**
     * Execute this function before calling any of the other functions of the
     * Provider. This allows any Provider-specific initialization to run before menus
     * and drivers are loaded, and also permits the Provider to block usage of the
     * plugin (for example, if the plugin provides services only available on
     * Microsoft Windows, but YAAC is being executed on Mac OS X).
     *
     * @param providerApiVersion the int version of the Provider API supported by
     *                           the build of YAAC trying to load this plugin
     * @return boolean false if this plugin cannot be loaded for some reason (such as
     *         missing pre-requisite software on the executing platform, or requiring
     *         a version of YAAC newer than the executing one)
     */
    @Override
    public boolean runInitializersBefore(int providerApiVersion) {
        return providerApiVersion >= 26;
    }

    /**
     * Get the explanation why the call to {@link #runInitializersBefore(int)} returned failure status.
     * If the localized error message has parameters that should be substituted
     * into it, overrides of this method should do the lookup and MessageFormat substitution itself rather than
     * expecting YAAC to do it, i.e.,
     * <code>
     * return MessageFormat.format(YAAC.getMsg(PLUGIN_NEEDS_NEWER_YAAC_PROTOCOL), YAAC.getCoreProviderVersion(), 15);
     * </code>
     * <p>The superclass method {@link #buildNewerYaacNeededMsg(int)} is available to produce such a
     * message if needed.</p>
     *
     * @return String of failure reason (or resource tag name if begun with a package-qualified Resource name), or null if the plugin successfully initialized
     * @see #runInitializersBefore(int)
     */
    @Override
    public String getInitFailureReason() {
        return buildNewerYaacNeededMsg(26);
    }

    /**
     * Execute this function after calling all of the other functions of the
     * Provider. This allows any Provider-specific initialization to run after menus
     * and drivers are loaded.
     */
    @Override
    public void runInitializersAfter() {
        if (!Boolean.parseBoolean((String)YAAC.getProps().get(YAAC.OPT_GUI))) {
            // add announcement listener for changes in station positions
            StationTracker.getInstance().addTrackerListener(new SampleVectorCalculator());
        }
    }

    /**
     * Specify attributions, credits/acknowledgements, and license references to be displayed in the
     * About dialog box. This method is called when the Help-&gt;About menu choice is
     * selected.
     *
     * @return array of localized Strings, each containing one attribution or acknowledgement
     */
    @Override
    public String[] getAboutAttributions() {
        return new String[]{
                "sample plugin \u00A9 2011-2022 Andrew Pavlin, KA2DDO"
        };
    }
}
